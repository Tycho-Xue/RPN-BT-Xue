from CaltechAnnotations import getall

caltechpath = '/data/stars/user/aabubakr/pd_datasets/datasets/caltech/annot' \
              '-new-sk30/images'


output = getall(caltechpath, 'train')